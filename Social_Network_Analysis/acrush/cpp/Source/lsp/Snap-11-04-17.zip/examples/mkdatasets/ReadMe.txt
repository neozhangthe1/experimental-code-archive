========================================================================
    MakeDatasets: creates datasets for the SNAP website
========================================================================

The code demonstrates how to load different kinds of networks in various
network formats and how to compute various statistics of the network, like
diameter, clustering coefficient, size of largest connected component, and
similar.

Depending on the platform (Windows or Linux) you need to edit the Makefile.
Use 'make opt' to compile the optimized (fast) version of the code.

/////////////////////////////////////////////////////////////////////////////
Parameters:

/////////////////////////////////////////////////////////////////////////////
Usage:
