========================================================================
    TestGraph: simple application 
========================================================================

The application demonstrates some of the basic functionality of the
SNAP library.

Depending on the platform (Windows or Linux) you need to edit the Makefile.
Use 'make opt' to compile the optimized (fast) version of the code.

/////////////////////////////////////////////////////////////////////////////
Parameters:

/////////////////////////////////////////////////////////////////////////////
Usage:
